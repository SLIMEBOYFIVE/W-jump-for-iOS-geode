# Sayo W Jump

A small Geode mod for Geometry Dash **2.2091 on iOS/iPadOS**. Pressing **W** on an external keyboard or keypad sends the game's normal Player 1 jump input. Releasing W releases the input, which matters in hold-based game modes.

## Requirements

- Geometry Dash 2.2091
- Geode 6.0.0 or newer
- An external keyboard/keypad that sends a normal **W key** event to iPadOS

## Build the iOS `.geode` file without a local Mac

This source project includes a GitHub Actions workflow. GitHub's macOS runner compiles the iOS build using the official Geode build action.

1. Create a GitHub repository and upload the contents of this folder (including the hidden `.github` folder).
2. Open the repository's **Actions** tab and allow workflows if GitHub asks.
3. Run **Build Sayo W Jump (iOS)**, or push the files to the `main` branch.
4. When the run finishes, open the run and download the artifact named **Sayo-W-Jump-iOS-2.2091**. It contains the `.geode` package.
5. Install that `.geode` file using the local-mod installation method supported by your Geode iOS launcher.

The project is source code plus a build workflow; it is **not** a precompiled `.geode` package. I have not run the iOS build or tested it on a physical iPad, so treat the first build as an unverified test build.

## Change the key

In Geometry Dash, open Geode's mod settings for **Sayo W Jump** and edit **Jump Key**. It defaults to `W`.

## How it works

The mod registers a Geode gameplay keybind. On key-down it calls `handleButton(true, 1, true)` and on key-up it calls `handleButton(false, 1, true)`. It tracks the active `PlayLayer` directly because the 2.2091 bindings have a known issue with `PlayLayer::get()`.

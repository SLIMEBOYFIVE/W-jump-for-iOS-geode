# Changelog

## 1.0.0
- Initial iOS build for Geometry Dash 2.2091.
- W key sends Player 1 jump press and release.
- Configurable gameplay keybind, defaulting to W.

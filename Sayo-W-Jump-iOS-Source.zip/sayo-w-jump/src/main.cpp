#include <Geode/Geode.hpp>
#include <Geode/loader/GameEvent.hpp>
#include <Geode/loader/SettingV3.hpp>
#include <Geode/modify/PlayLayer.hpp>

using namespace geode::prelude;

namespace {
    // Keep our own PlayLayer pointer. In GD 2.2091, PlayLayer::get() reads
    // a misplaced GameManager field, so the mod tracks the active layer itself.
    PlayLayer* s_playLayer = nullptr;
    bool s_jumpHeld = false;

    void releaseJumpIfNeeded() {
        if (s_playLayer && s_jumpHeld) {
            // Button 1 is the normal Geometry Dash jump input; true = Player 1.
            s_playLayer->handleButton(false, 1, true);
        }
        s_jumpHeld = false;
    }
}

class $modify(SayoWJumpPlayLayer, PlayLayer) {
    struct Fields {
        PlayLayer* owner = nullptr;

        ~Fields() {
            // Fallback cleanup in case the level is destroyed without onQuit.
            if (owner && s_playLayer == owner) {
                s_playLayer = nullptr;
                s_jumpHeld = false;
            }
        }
    };

    bool init(GJGameLevel* level, bool dontCreateObjects) {
        if (!PlayLayer::init(level, dontCreateObjects)) {
            return false;
        }

        s_playLayer = this;
        m_fields->owner = this;
        s_jumpHeld = false;
        return true;
    }

    void onQuit() {
        releaseJumpIfNeeded();
        if (s_playLayer == this) {
            s_playLayer = nullptr;
        }
        PlayLayer::onQuit();
    }
};

$on_mod(Loaded) {
    listenForKeybindSettingPresses(
        "jump-key",
        [](Keybind const&, bool down, bool repeat, double) -> bool {
            auto* layer = s_playLayer;
            if (!layer) {
                return false;
            }

            if (down) {
                // Ignore OS key-repeat events, but keep the original press held.
                if (!repeat && !s_jumpHeld) {
                    s_jumpHeld = true;
                    layer->handleButton(true, 1, true);
                }
            } else if (s_jumpHeld) {
                s_jumpHeld = false;
                layer->handleButton(false, 1, true);
            }

            // Consume W while the level is active; the mod has already forwarded
            // it as the game's normal jump input.
            return true;
        }
    );
}
